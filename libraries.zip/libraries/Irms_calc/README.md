# Irms calculator
Calculate Vpp, Vrms, Irms for current sensors like ACS712
